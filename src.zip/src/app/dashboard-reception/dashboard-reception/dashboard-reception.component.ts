import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-reception',
  templateUrl: './dashboard-reception.component.html',
  styleUrls: ['./dashboard-reception.component.scss']
})
export class DashboardReceptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
