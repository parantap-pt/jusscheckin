import { Component, OnInit, OnDestroy } from '@angular/core';
import { API_URLS } from '../../api_config/app.constants';
//import { HttpInterceptor } from "../../http_services/httpinterceptor";
//import { HttpClient, HttpHeaders } from '@angular/common/http';
//import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
	 
	  constructor(
	  	//private http: HttpInterceptor,
	    //private https: HttpClient,
	    //private formBuilder: NgForm
      ) { }

	  ngOnInit(): void {

	  }
	 

}
