import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-manager',
  templateUrl: './login-manager.component.html',
  styleUrls: ['./login-manager.component.scss']
})
export class LoginManagerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
