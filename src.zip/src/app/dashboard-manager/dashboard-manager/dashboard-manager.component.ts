import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-manager',
  templateUrl: './dashboard-manager.component.html',
  styleUrls: ['./dashboard-manager.component.scss']
})
export class DashboardManagerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
