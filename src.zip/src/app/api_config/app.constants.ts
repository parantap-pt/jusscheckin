'use strict';
const API_LINK = 'http://jusscheckin.amazingwebprojects.com/api/';

export const API_URLS = {
	MAIL_API : API_LINK+'contacts',

	DATEFORMATE: "MM/dd/yyyy",
	FILE_PATH: 'https://oy.oyprice.com/',
	GET_MENU:API_LINK +"menu",
	GET_PRODUCT_CATLOG:API_LINK+'catlog/'

};
