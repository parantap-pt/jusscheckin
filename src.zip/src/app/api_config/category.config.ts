'use strict';


export const CATEGORY_IDS = {

	mobile: "1",
	laptop: "2",
	camera: "3",
	lens:   "4",
	tv:"5",
	headphone:"7",
	desktop:'22',
	graphiccard:'21',
	gamesoftware:'13',
	tablet:'23',
	monitor:'24'
};

export const BLOG_CATEGORY_IDS = {

	mobile: "24",
	laptop: "25",
	camera: "26",
	lens:   "31",
	tv:"28",
	headphone:"27",
	desktop:'32',
	graphiccard:'33',
	gamesoftware:'30',
	tablet:'34',
	monitor:'29'
};
