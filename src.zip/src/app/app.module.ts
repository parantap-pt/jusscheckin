import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer/footer.component';
import { HeaderComponent } from './header/header/header.component';
import { HomeComponent } from './home/home/home.component';
import { LoginComponent } from './login/login/login.component';
import { LoginManagerComponent } from './login/login-manager/login-manager.component';
import { DashboardComponent } from './dashboard/dashboard/dashboard.component';
import { DashboardAccountComponent } from './dashboard-account/dashboard-account/dashboard-account.component';
import { DashboardManagerComponent } from './dashboard-manager/dashboard-manager/dashboard-manager.component';
import { DashboardReceptionComponent } from './dashboard-reception/dashboard-reception/dashboard-reception.component';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HeaderComponent,
    HomeComponent,
    LoginComponent,
    LoginManagerComponent,
    DashboardComponent,
    DashboardAccountComponent,
    DashboardManagerComponent,
    DashboardReceptionComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
