import { Injectable } from "@angular/core"
import { Observable } from "rxjs/Rx"
import { HttpClient, HttpHeaders } from '@angular/common/http';
// operators
import "rxjs/add/operator/catch"
import "rxjs/add/observable/throw"
import "rxjs/add/operator/map"
declare var $: any;

@Injectable()
export class HttpInterceptor {
    constructor(private http: HttpClient,
        // private router: Router,
        //private toasterService: ToasterService
        ) {
        //this.toasterService = toasterService;

    }

    public get(url:any, data:any, flash_flag :any): Observable<any> {

        // var token = '';
        return this.http.get(url, {
            headers: new HttpHeaders()})
            .map((res: any) => {
                
                return res;

            })
            .catch((error: any) => {
                
                return Observable.throw(error);
            })
    }

     public post(url:any, data:any, flash_flag:any): Observable<any> {

        // var token = '';
        return this.http.post(url, data, {
            headers: new HttpHeaders()
            // .set('Content-Type','application/json')
            //  // .set('Access-Control-Allow-Origin', '*')
             // .set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE')
            // .set('Access-Control-Allow-Headers', 'X-Requested-With,content-type')
            // .set('Access-Control-Allow-Credentials', 'true')
            // .set('Host', 'oyprice.com')
            // .set('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE, HEAD, OPTIONS')


//             xhr.setRequestHeader("User-Agent", "PostmanRuntime/7.20.1");
// xhr.setRequestHeader("Accept", "*/*");
// xhr.setRequestHeader("Cache-Control", "no-cache");
// xhr.setRequestHeader("Postman-Token", "b756175c-ca3e-4ea1-922e-63cc07c5275c,158693c4-51fc-4317-be43-d4f01f58f298");
// xhr.setRequestHeader("Host", "oyprice.com");
// xhr.setRequestHeader("Content-Type", "multipart/form-data; boundary=--------------------------980441367242888636508356");
// xhr.setRequestHeader("Accept-Encoding", "gzip, deflate");
// xhr.setRequestHeader("Content-Length", "305");
// xhr.setRequestHeader("Connection", "keep-alive");
// xhr.setRequestHeader("cache-control", "no-cache");



        })
            .map((res: any) => {
                
                return res;

            })
            .catch((error: any) => {
                
                return Observable.throw(error);
            })
    }
}